package gof.prototype;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.Matchers.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class CarTest {
	protected Car originalCar;

	@Before
	public void setUp() throws Exception {
		originalCar = new Car("A6", 1.9, 130);
	}

	@Test
	public void testConstructor() {
		assertNotNull("the original car hasn't been created", originalCar);		
	}

	@Test
	public void testTune() {
		originalCar.engine = Mockito.mock(Engine.class);
		originalCar.tune();
		verify(originalCar.engine).tune();		
	}

	@Test
	public void testShallowClone() {
		Car shallowCopyOfCar = originalCar.shallowClone();
		
		assertNotNull("shallowClone() hasn't returned a copy", shallowCopyOfCar);
		assertNotSame("the original car and the copy are the same object", originalCar, shallowCopyOfCar);
		assertEquals("the original car and the copy are not equal", originalCar, shallowCopyOfCar);
		assertSame("the engine attribute in both cars do not point to the same object", originalCar.engine, shallowCopyOfCar.engine);
		
	}

	@Test
	public void testDeepClone() {
		Car deepCopyOfCar = originalCar.deepClone();
		
		assertNotNull("deepClone() hasn't returned a copy", deepCopyOfCar);
		assertNotSame("the original car and the copy are the same object", originalCar, deepCopyOfCar);
		assertEquals("the original car and the copy are not equal", originalCar, deepCopyOfCar);
		assertNotSame("the engine attribute in both cars point to the same object", originalCar.engine, deepCopyOfCar.engine);
	}

}
