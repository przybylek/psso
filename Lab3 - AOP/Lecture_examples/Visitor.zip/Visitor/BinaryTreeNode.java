public class BinaryTreeNode implements BinaryTree {

  protected BinaryTree left; //the left subtree
  protected BinaryTree right;//the right subtree
	 	
  public BinaryTree getLeft() {
    return left;
  }

  public BinaryTree getRight() {
    return right;
  }
    
  public BinaryTreeNode(BinaryTree left, BinaryTree right) {
    this.left  = left;
    this.right = right;
  }
}