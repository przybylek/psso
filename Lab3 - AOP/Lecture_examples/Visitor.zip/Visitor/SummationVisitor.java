public class SummationVisitor implements VisitorProtocol.Visitor {
  protected int sum = 0;

  public void visit(VisitorProtocol.Node node) {                      
    BinaryTreeNode btnode = (BinaryTreeNode) node; 
    btnode.getLeft().accept(this);
    btnode.getRight().accept(this);
  }
		
  public void visit(VisitorProtocol.Leaf leaf) { 
    BinaryTreeLeaf btleaf = (BinaryTreeLeaf) leaf;
    sum += btleaf.getValue();
  }
	  
  public int getSum() {
    return sum;
  }
}