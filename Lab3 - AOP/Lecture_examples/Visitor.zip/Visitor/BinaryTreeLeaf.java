public class BinaryTreeLeaf implements BinaryTree {
  protected int value;
   
  public BinaryTreeLeaf(int value) {
    this.value = value;
  } 
	
  public int getValue() {
    return value;
  }
}