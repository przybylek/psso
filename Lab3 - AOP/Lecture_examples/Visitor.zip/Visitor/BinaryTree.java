public interface BinaryTree {}
	
