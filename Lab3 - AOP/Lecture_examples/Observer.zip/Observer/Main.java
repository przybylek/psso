import java.awt.Color; 

public class Main {               
    

    public static void main(String argv[]) {
	
    	Point p1 = new Point(0, 0, Color.blue);
    	Point p2 = new Point(2, 2, Color.red);
    	Point p3 = new Point(4, 4, Color.red);
    	Line l1 = new Line(p2,p3, Color.red);
    	
    	Screen s1 = new Screen("s1");
    	Screen s2 = new Screen("s2");
    	
    	System.out.println("Sreen s1 observes positions");
    	System.out.println("Sreen s2 observes colors");
        
    	PositionObserver.aspectOf().addObserver(p1, s1);    
    	PositionObserver.aspectOf().addObserver(l1, s1);
    	ColorObserver.aspectOf().addObserver(p1, s2);    
    	ColorObserver.aspectOf().addObserver(l1, s2);
    	
        System.out.println("Changing l1's color:");    	
    	l1.setColor(Color.green);

        System.out.println("Moveing l1's by [6;6]:");    	
    	l1.moveBy(6,6); 
    	
    	System.out.println("Changing p1's x-coordinate:");
    	p1.setX(1); 

    }
}
