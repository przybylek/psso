public class Screen {
  private String name;
    
  public Screen(String s) {
    this.name = s;
  }
     
  public void display(String s) {
	    System.out.println(name + ": " + s);
  }   

  public void refresh(ObserverProtocol.Subject s) { 
      display(s.toString());
  }
  
}
