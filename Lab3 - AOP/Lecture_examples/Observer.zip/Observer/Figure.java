import java.awt.Color;

public abstract class Figure {
    private Color color;
    protected Figure(Color color) {
    	this.color=color; 
    }
    public Color getColor() { 
    	return color; 
    }
    public void setColor(Color color) { 
    	this.color=color; 
    }
    public abstract void moveBy(int dx, int dy);
}
 