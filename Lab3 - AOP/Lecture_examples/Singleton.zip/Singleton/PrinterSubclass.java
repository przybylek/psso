
 
/**
 * Implements a sample subclass of the <i>Singleton</i> class. This class is 
 * to test whether subclasses can still access the Singleton's constructor.
 *
 * @author  Jan Hannemann
 * @author  Gregor Kiczales
 * @version 1.1, 02/18/04
 * 
 * @see PrinterSingleton
 */


public class PrinterSubclass extends Printer { 

    /**
     * Creates an instance of this class by calling <code>super()</code>.
     */
    
	public PrinterSubclass() {
		super();
	}
}