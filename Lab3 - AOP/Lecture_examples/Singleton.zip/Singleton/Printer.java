

/**
 * Implements a sample class that will be assigned the <i>Singleton</i> role
 * in this example. The class's functionality
 * is to store an instance-specific ID and provide a <code>print()</code>
 * method that shows an object's ID.  
 *
 * Note that in this implementation the class does not have to know
 * that it is a <i>Singleton</i> (i.e. has no pattern code in it).
 * 
 * Note further that instead of assigning the <i>Singleton</i> property
 * via the <code>declare parents</code> construct in the aspect, it is
 * possible to just add a <code>implements Singleton</doce> here. However,
 * that would introduce pattern-related code into this type.
 *
 * @author  Jan Hannemann
 * @author  Gregor Kiczales
 * @version 1.1, 02/18/04
 */

public class Printer { 	 

    /**
     * counts the instances of this class
     */
      
	protected static int objectsSoFar = 0;

    /**
     * each instance has an ID to distinguish them.
     */
  
	protected int id;

	/**
	 * Creates a <code>Printer</code> object. Note that the constructor
	 * is not protected; the protection is realized by the aspect.
	 */
	
	public Printer() {
		id = ++objectsSoFar;
	}
	
    /**
     * Prints the instance's ID to <code>System.out</code>.
     */
    
	public void print() {
		System.out.println("\tMy ID is "+id);
	}
}
	