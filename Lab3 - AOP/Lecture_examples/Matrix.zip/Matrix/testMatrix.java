public class testMatrix {

    public static void main(String[] args) {
        Matrix A = Matrix.random(1000,100);
		Matrix B = Matrix.random(100,1000);
		Matrix C = A.times(B);		
		System.out.println(A.transpose().plus(B));
		
    }
}
