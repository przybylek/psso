public class LogMatrix extends Matrix {

 public LogMatrix(int M, int N) {
  super(M,N);
 }

 public LogMatrix(double[][] data) {
  super(data);
 }

 private LogMatrix(Matrix A) { 
  super(A);
 }


  protected void swap(int i, int j) {
    long start = System.currentTimeMillis();
    super.swap(i,j);
    long end = System.currentTimeMillis();
    long time = end - start;
    System.out.println("void Matrix.swap(int,int) - " + time);

  }

  public LogMatrix transpose() {
    long start = System.currentTimeMillis();
    LogMatrix m = new LogMatrix(super.transpose());
    long end = System.currentTimeMillis();
    long time = end - start;
    System.out.println("Matrix Matrix.transpose() - " + time);
    return m;
  }

    // test client
    public static void main(String[] args) {
        double[][] d = { { 1, 2, 3 }, { 4, 5, 6 }, { 9, 1, 3} };
        Matrix D = new LogMatrix(d);
        D.swap(1, 2);
        D.show();
        Matrix E = new LogMatrix( Matrix.random(500,500) );   
	E.transpose(); 

    }
}
