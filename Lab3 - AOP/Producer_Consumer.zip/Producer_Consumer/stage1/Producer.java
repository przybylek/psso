public class Producer extends Thread {
  private Queue buffer;
  private int times;
  public Producer(Queue buffer, int times) {
    this.buffer = buffer;
    this.times = times;
  }
  public int produce() {	
    Integer product = new Integer( (int)(Math.random()*1000) );
    return product;
  }

  public void run() {
    for (int i=times; i>0; i--) {
      Integer product = produce();	
      buffer.put(product);
    }
  }
}