public class Consumer extends Thread {
  private Queue buffer;

  public Consumer(Queue buffer) {
    this.buffer = buffer;
  }

  public void consume(Integer product) {
    System.out.println("Zjadam " + product.intValue());
    try {
      sleep(product.intValue()*2);
    } catch (InterruptedException e) { }
  }

  public void run() {
    while(true) {
      Integer product = (Integer)buffer.get();
      consume(product);
    }
  }
}