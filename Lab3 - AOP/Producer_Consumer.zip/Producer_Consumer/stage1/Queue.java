public class Queue {
  protected Object[] buf;
  protected int numItems; 
  protected int nextToRemove;

  public Queue(int capacity) {
    buf = new Object[capacity];
  }

  public boolean isFull() {
    return (numItems==buf.length);   
  }

  public boolean isEmpty() {
    return (numItems==0);   
  }

  public int size() {
    return numItems;
  }

  public boolean put(Object x) {
    if ( isFull() ) return false;
    buf[(nextToRemove+numItems) % buf.length] = x;    
    numItems++;
    return true;   
  }

  public Object get() {
    Object tmp=null;
    if ( !isEmpty() ) {
      tmp = buf[nextToRemove];
      numItems--;
      nextToRemove = (nextToRemove+1) % buf.length;
    }
    return tmp;
  }
}



