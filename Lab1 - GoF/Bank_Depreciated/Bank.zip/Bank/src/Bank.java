import java.util.HashMap;
import java.util.Map;


public class Bank {

    private Map<String,Account> accounts;
    private Map<String,Customer> customers;
    
    public Bank() {
        accounts = new HashMap();
        customers = new HashMap();
    }
    
    public void addCustomer(String firstName, String lastName, String pesel) throws BankException {
        if (getCustomer(pesel) != null) throw new BankException("This customer already exists!");
        Customer customer= new Customer(pesel, firstName, lastName);
        customers.put(pesel, customer);        
    }

    public void openAccount(String id, Customer owner) throws BankException {
        if (getAccount(id) != null) throw new BankException("Rachunek o tym numerze juz istnieje!");
        Account account = new Account(id, owner);
        accounts.put(id, account);
    }
    
    private Customer getCustomer(String pesel) {
        return customers.get(pesel);
    }
   
    private Account getAccount(String id) {
        return accounts.get(id);
    }

    public static void main(String[] args) throws BankException {
        Bank bank = new Bank();
        Customer jan = new Customer("Jan", "Kowalski", "85072309675");
        Customer anna = new Customer("Anna", "Nowak", "87110314523");
        bank.openAccount("123abc", jan);
        bank.openAccount("456zxy", anna);
        
        Account acc123 = bank.getAccount("123abc");
        Account acc456 = bank.getAccount("456zxy");
        
        acc123.deposit(1000);
        acc456.deposit(700);
        
        acc456.transferTo(acc123, 200);
        acc123.changeInterest(new CompoundInterest());
        
        acc123.addInterest(1);
        acc456.addInterest(1);
        
        System.out.println(acc123);
        System.out.println(acc456); 
    }
}