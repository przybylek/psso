public class SimpleInterest implements Interest {
    protected double rate = 0.01;
    
    public double compute(double principle, double time) {
        return principle*rate*time;
    }    
    
    public String toString() {
        return "simple, r="+rate;
    }
}
