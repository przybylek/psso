
public interface Interest {
   public double compute(double principle, double time);
}
