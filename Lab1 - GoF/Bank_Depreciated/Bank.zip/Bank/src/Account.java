public class Account {

    protected String id;
    protected Customer owner;
    protected double balance; 
    protected Interest interest = new SimpleInterest();
    
    public Account(String id, Customer customer) {
        this.id = id;
        this.owner = customer;
    }
            
    public void deposit(double amount) throws BankException {
        if (amount < 0) throw new BankException("Kwota wplaty musi byc nieujemna");    
        this.balance += amount;
    }
    
    public void withdraw(double amount) throws BankException {
        if (this.balance < amount) throw new BankException("Prosba wyplaty ponad saldo na rachunku");
        if (amount < 0) throw new BankException("Kwota wyplaty musi byc nieujemna");
        this.balance -= amount;
    }
        
    public double getBalance() {
        return this.balance;
    }
    
    public Customer owner() {
    	return owner;
    }
          
    public void transferTo(Account account, double amount) throws BankException {
        if (amount > balance) throw new BankException("Prosba przelewu ponad saldo rachunku");        
        withdraw(amount);
        account.deposit(amount);
    }
    public void changeInterest(Interest interest) {
        this.interest = interest;
    }
    
    public void addInterest(double time) throws BankException {      
        deposit( interest.compute(balance, time) );
    }
    
    public String toString() {
        return "Id: " + id + "; balance: " + balance + "; interest: " + interest + "; owner: " + owner();
    } 
}
