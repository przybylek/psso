package gof.bank;


public class AddInterest implements Command {
    private double time;
    
    public AddInterest(double time) {
        this.time = time;
    }
    public void execute(Account account) throws BankException {
        double interest = account.interest.compute(account.balance, time);
        account.doOperation(new Deposit(interest));
    }


    
}
