package gof.bank;


public class Customer {

    protected String firstName;
    protected String lastName;
    protected String PESEL;

    public Customer(String firstName, String lastName, String pesel) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.PESEL = pesel;
    }
    
    public String toString() {
    	return "(" + PESEL + ") " + firstName + " " + lastName;
    }
    
}
