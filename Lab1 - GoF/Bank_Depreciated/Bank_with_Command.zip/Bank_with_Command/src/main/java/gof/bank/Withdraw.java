package gof.bank;

public class Withdraw implements Command {
    protected double amount;
    
    public Withdraw(double amount) {
        if (amount > 0) this.amount = amount;
    }
    
    public void execute(Account account) throws BankException {
        if (account.balance < amount) throw new BankException("Prosba wyplaty ponad saldo na rachunku");
        account.balance -= amount;   
    }    
}
