package gof.bank;

public class Account {//Invoker and Receiver

    protected String id;
    protected Customer owner;
    protected double balance; 
    protected Interest interest = new SimpleInterest();
    
    public Account(String id, Customer customer) {
        this.id = id;
        this.owner = customer;
    }
               
    public Customer owner() {
    	return owner;
    }
    
    public void doOperation(Command operation) throws BankException {
    	operation.execute(this);
    }
        
    public String toString() {
        return "Id: " + id + "; balance: " + balance + "; interest: " + interest + "; owner: " + owner();
    } 
}
