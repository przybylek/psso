package gof.bank;

public class Deposit implements Command {
    protected double amount;
    
    public Deposit(double amount) {
        if (amount > 0) this.amount = amount;
    }
    
    public void execute(Account account) {        
        account.balance += amount;   
    }
    
}
