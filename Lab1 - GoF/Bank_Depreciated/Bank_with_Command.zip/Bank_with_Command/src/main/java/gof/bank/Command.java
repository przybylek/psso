package gof.bank;

public interface Command {//Operation
	public void execute(Account account) throws BankException;
}
