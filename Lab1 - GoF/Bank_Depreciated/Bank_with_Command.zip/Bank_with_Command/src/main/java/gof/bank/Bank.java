package gof.bank;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;

public class Bank {// Client

	private Map<String, Account> accounts;
	private Map<String, Customer> customers;

	public Bank() {
		accounts = new HashMap<>();
		customers = new HashMap<>();
	}

	public void addCustomer(String firstName, String lastName, String pesel)
			throws BankException {
		if (getCustomer(pesel) != null)
			throw new BankException("This customer already exists!");
		Customer customer = new Customer(pesel, firstName, lastName);
		customers.put(pesel, customer);
	}

	public void openAccount(String id, Customer owner) throws BankException {
		if (getAccount(id) != null)
			throw new BankException("Rachunek o tym numerze juz istnieje!");
		Account account = new Account(id, owner);
		accounts.put(id, account);
	}

	private Customer getCustomer(String pesel) {
		return customers.get(pesel);
	}

	private Account getAccount(String id) {
		return accounts.get(id);
	}

	public void transfer(Account accountFrom, Account accountTo, double amount)
			throws BankException {
		TransferTo transferTo = new TransferTo(accountTo, amount);
		accountFrom.doOperation(transferTo);
	}

	public void transfer(String accountIdFrom, String accountIdTo, double amount)
			throws BankException {
		Account accountFrom = getAccount(accountIdFrom);
		Account accountTo = getAccount(accountIdTo);
		transfer(accountFrom, accountTo, amount);
	}

	public void deposit(Account account, double amount) throws BankException {
		Deposit deposit = new Deposit(amount);
		account.doOperation(deposit);
	}

	public void withdraw(Account account, double amount) throws BankException {
		Withdraw withdraw = new Withdraw(amount);
		account.doOperation(withdraw);
	}

	public void interestChange(Account account, Interest interest)
			throws BankException {
		InterestChange interestChange = new InterestChange(interest);
		account.doOperation(interestChange);
	}

	public void addInterest(Account account, double time) throws BankException {
		AddInterest addInterest = new AddInterest(1);
		account.doOperation(addInterest);
	}



	public static void main(String[] args) throws BankException {

		Bank bank = new Bank();
		Customer jan = new Customer("Jan", "Kowalski", "85072309675");
		Customer anna = new Customer("Anna", "Nowak", "87110314523");
		bank.openAccount("123abc", jan);
		bank.openAccount("456zxy", anna);

		Account acc123 = bank.getAccount("123abc");
		Account acc456 = bank.getAccount("456zxy");

		bank.deposit(acc123, 1000);
		bank.deposit(acc456, 700);

		bank.transfer(acc456, acc123, 200);

		bank.interestChange(acc123, new CompoundInterest());

		bank.addInterest(acc123, 1);
		bank.addInterest(acc456, 1);

		System.out.println(acc123);
		System.out.println(acc456);
	}
}
