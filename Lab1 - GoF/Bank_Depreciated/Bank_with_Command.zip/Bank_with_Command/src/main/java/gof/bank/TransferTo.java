package gof.bank;

public class TransferTo implements Command {
    protected Account accountTo;
    protected double amount;
    
    public TransferTo(Account accountTo, double amount) {
        this.accountTo = accountTo;
        this.amount = amount;
    }
    
    public void execute(Account accountFrom) throws BankException {
        accountFrom.doOperation(new Withdraw(amount));
        accountTo.doOperation(new Deposit(amount));
    }
    
    
}
