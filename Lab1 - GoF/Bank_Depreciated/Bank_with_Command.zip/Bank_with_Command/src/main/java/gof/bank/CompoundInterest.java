package gof.bank;

public class CompoundInterest implements Interest {
    protected double rate = 0.009;
      
    public double compute(double principle, double time) {
        return principle * (Math.pow((1 + rate),time)-1);
    }
    
    public String toString() {
        return "compound, r="+rate;
    }
}
