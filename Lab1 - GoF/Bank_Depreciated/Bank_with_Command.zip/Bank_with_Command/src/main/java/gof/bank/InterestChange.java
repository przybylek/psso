package gof.bank;


public class InterestChange implements Command {
    protected Interest interest;
    
    public InterestChange(Interest interest) {
        this.interest=interest;
    }
    
    public void execute(Account account) throws BankException {
        account.interest = interest;        
    }
}
