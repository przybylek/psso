package gof.bank;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BankTest {
	private Account sourceAccount;
	private Account targetAccount;

	@Before
	public void setUp() throws Exception {
		sourceAccount = new Account("123abc", new Customer("Jan", "Kowalski", "85072309675"));
		targetAccount = new Account("456zxy", new Customer("Anna", "Nowak", "87110314523"));
	}

	@Test
	public void testDeposit() {	
		double amount = 100;
        Deposit deposit = new Deposit(amount);
        try {
			sourceAccount.doOperation(deposit);
		} catch (BankException e) {
			fail("Can't deposit money");
		}		
        assertTrue(sourceAccount.balance==amount);
	}

	@Test
	public void testWithdraw() {
		testDeposit();
		double amount = sourceAccount.balance;
		Withdraw withdraw = new Withdraw(amount);
		try {
			sourceAccount.doOperation(withdraw);
		} catch (BankException e) {
			fail("Can't withdraw money");
		}		
		assertTrue(sourceAccount.balance==0);
		try {
			sourceAccount.doOperation(withdraw);
		} catch (BankException e) {
			//exception should be thrown
			return;
		}	
		fail("Withdraw money when the balance is 0");
		
	}

}
