package gof.decorator;

import java.io.*;



public class PackerOutputStream extends FilterOutputStream {


}
