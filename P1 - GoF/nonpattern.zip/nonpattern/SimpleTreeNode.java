//Define tree element with no children

public class SimpleTreeNode extends TreeNode  {

  public SimpleTreeNode(String label) {
    super(label);
  }

  public void inFixPrint()  {

  }
  
}